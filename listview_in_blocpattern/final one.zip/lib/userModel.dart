class UserModel {
  String email;
  String uId;
  UserModel(this.email, this.uId);
}
