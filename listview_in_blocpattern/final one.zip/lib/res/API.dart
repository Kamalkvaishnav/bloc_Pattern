class AppStrings {
  static String apikey =
      "https://fcm.googleapis.com/fcm/send";
}